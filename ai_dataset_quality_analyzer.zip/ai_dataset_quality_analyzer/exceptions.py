class DatasetError(Exception):
    """Base exception for dataset-related errors."""


class DatasetNotFoundError(DatasetError):
    """Raised when the input dataset does not exist."""


class InvalidDatasetError(DatasetError):
    """Raised when the dataset cannot be read or has no usable columns."""

import argparse
import sys

from analyzer import analyze_dataset
from data_loader import load_csv
from exceptions import DatasetError
from report_generator import create_markdown_report


def build_parser():
    parser = argparse.ArgumentParser(
        description="Analyze a CSV dataset and identify common quality issues."
    )
    parser.add_argument("--file", required=True, help="Path to the input CSV file")
    parser.add_argument("--report", help="Optional path for a Markdown report")
    parser.add_argument(
        "--required",
        default="",
        help="Comma-separated list of columns that must exist",
    )
    return parser


def print_report(report):
    print("\nDATASET QUALITY SUMMARY")
    print("-" * 30)
    print(f"Rows: {report['row_count']}")
    print(f"Columns: {report['column_count']}")
    print(f"Completeness: {report['completeness_percent']:.2f}%")
    print(f"Duplicate rows: {report['duplicate_rows']}")

    print("\nMissing values:")
    for column, count in report["missing_by_column"].items():
        print(f"  {column}: {count}")

    print("\nNumeric columns:")
    for column, stats in report["numeric_summary"].items():
        print(
            f"  {column}: min={stats['min']:.2f}, max={stats['max']:.2f}, "
            f"average={stats['average']:.2f}"
        )

    print("\nValidation:")
    print(f"  Duplicate columns: {report['duplicate_columns'] or 'None'}")
    print(
        "  Missing required columns: "
        f"{report['missing_required_columns'] or 'None'}"
    )


def main():
    args = build_parser().parse_args()
    required = [item.strip() for item in args.required.split(",") if item.strip()]

    try:
        headers, rows = load_csv(args.file)
        report = analyze_dataset(headers, rows, required)
        print_report(report)

        if args.report:
            output = create_markdown_report(report, args.report)
            print(f"\nMarkdown report saved to: {output}")

    except DatasetError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

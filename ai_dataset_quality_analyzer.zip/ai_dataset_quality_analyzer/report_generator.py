from pathlib import Path


def create_markdown_report(report, output_path):
    """Write analysis results to a Markdown file."""
    lines = [
        "# Dataset Quality Report",
        "",
        "## Overview",
        f"- Rows: {report['row_count']}",
        f"- Columns: {report['column_count']}",
        f"- Completeness: {report['completeness_percent']:.2f}%",
        f"- Duplicate rows: {report['duplicate_rows']}",
        "",
        "## Columns",
    ]

    lines.extend(f"- `{header}`" for header in report["headers"])

    lines.extend(["", "## Missing values", "| Column | Missing |", "|---|---:|"])
    lines.extend(
        f"| {column} | {count} |"
        for column, count in report["missing_by_column"].items()
    )

    lines.extend(["", "## Numeric summary", "| Column | Count | Min | Max | Average |", "|---|---:|---:|---:|---:|"])
    if report["numeric_summary"]:
        for column, stats in report["numeric_summary"].items():
            lines.append(
                f"| {column} | {stats['count']} | {stats['min']:.2f} | "
                f"{stats['max']:.2f} | {stats['average']:.2f} |"
            )
    else:
        lines.append("| No numeric columns found | - | - | - | - |")

    lines.extend(["", "## Validation"])
    lines.append(
        f"- Duplicate column names: {', '.join(report['duplicate_columns']) or 'None'}"
    )
    lines.append(
        f"- Missing required columns: {', '.join(report['missing_required_columns']) or 'None'}"
    )

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path

from collections import Counter


MISSING_MARKERS = {"", "na", "n/a", "null", "none", "nan"}


def is_missing(value):
    return value is None or str(value).strip().lower() in MISSING_MARKERS


def find_missing_values(headers, rows):
    """Return missing-value counts for every column."""
    return {
        header: sum(1 for row in rows if is_missing(row.get(header)))
        for header in headers
    }


def find_duplicate_rows(rows):
    """Return the number of duplicate rows after normalizing cell values."""
    normalized = [tuple(sorted((key, value) for key, value in row.items())) for row in rows]
    counts = Counter(normalized)
    return sum(count - 1 for count in counts.values() if count > 1)


def find_duplicate_columns(headers):
    normalized = [header.strip().lower() for header in headers]
    counts = Counter(normalized)
    return sorted(name for name, count in counts.items() if count > 1)


def numeric_summary(headers, rows):
    """Calculate count, min, max and average for columns containing numeric values."""
    summary = {}

    for header in headers:
        values = []
        for row in rows:
            value = row.get(header, "")
            if is_missing(value):
                continue
            try:
                values.append(float(value))
            except (TypeError, ValueError):
                continue

        if values:
            summary[header] = {
                "count": len(values),
                "min": min(values),
                "max": max(values),
                "average": sum(values) / len(values),
            }

    return summary


def check_required_columns(headers, required_columns):
    available = {header.strip().lower() for header in headers}
    return [column for column in required_columns if column.strip().lower() not in available]


def analyze_dataset(headers, rows, required_columns=None):
    required_columns = required_columns or []
    missing = find_missing_values(headers, rows)
    duplicate_rows = find_duplicate_rows(rows)
    duplicate_columns = find_duplicate_columns(headers)
    numeric = numeric_summary(headers, rows)
    missing_required = check_required_columns(headers, required_columns)

    total_cells = len(headers) * len(rows)
    missing_cells = sum(missing.values())
    completeness = 100.0 if total_cells == 0 else (total_cells - missing_cells) / total_cells * 100

    return {
        "row_count": len(rows),
        "column_count": len(headers),
        "headers": headers,
        "missing_by_column": missing,
        "missing_cells": missing_cells,
        "completeness_percent": completeness,
        "duplicate_rows": duplicate_rows,
        "duplicate_columns": duplicate_columns,
        "numeric_summary": numeric,
        "missing_required_columns": missing_required,
    }

import csv
from pathlib import Path

from exceptions import DatasetNotFoundError, InvalidDatasetError


def load_csv(file_path):
    """Load a CSV file and return (headers, rows)."""
    path = Path(file_path)

    if not path.exists():
        raise DatasetNotFoundError(f"Dataset not found: {path}")

    try:
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames

            if not headers:
                raise InvalidDatasetError("The CSV file is empty or has no header row.")

            cleaned_headers = [header.strip() for header in headers]
            if any(not header for header in cleaned_headers):
                raise InvalidDatasetError("The CSV contains an empty column name.")

            rows = []
            for raw_row in reader:
                row = {}
                for key, value in raw_row.items():
                    if key is not None:
                        row[key.strip()] = (value or "").strip()
                rows.append(row)

            return cleaned_headers, rows

    except UnicodeDecodeError as error:
        raise InvalidDatasetError("Could not decode the CSV. Save it as UTF-8.") from error
    except csv.Error as error:
        raise InvalidDatasetError(f"Invalid CSV format: {error}") from error

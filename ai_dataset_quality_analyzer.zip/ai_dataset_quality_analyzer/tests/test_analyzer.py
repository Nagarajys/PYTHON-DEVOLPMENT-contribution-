import unittest

from analyzer import (
    analyze_dataset,
    find_duplicate_rows,
    find_missing_values,
    numeric_summary,
)


class AnalyzerTests(unittest.TestCase):
    def setUp(self):
        self.headers = ["name", "age", "score"]
        self.rows = [
            {"name": "Asha", "age": "19", "score": "88"},
            {"name": "Ravi", "age": "20", "score": ""},
            {"name": "Asha", "age": "19", "score": "88"},
        ]

    def test_missing_values(self):
        result = find_missing_values(self.headers, self.rows)
        self.assertEqual(result["score"], 1)

    def test_duplicate_rows(self):
        self.assertEqual(find_duplicate_rows(self.rows), 1)

    def test_numeric_summary(self):
        result = numeric_summary(self.headers, self.rows)
        self.assertEqual(result["age"]["count"], 3)
        self.assertAlmostEqual(result["age"]["average"], 58 / 3)

    def test_full_analysis(self):
        result = analyze_dataset(self.headers, self.rows, ["name", "email"])
        self.assertEqual(result["row_count"], 3)
        self.assertEqual(result["missing_required_columns"], ["email"])


if __name__ == "__main__":
    unittest.main()

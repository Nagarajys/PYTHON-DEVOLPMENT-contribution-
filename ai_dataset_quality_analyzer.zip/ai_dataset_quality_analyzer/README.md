# AI Dataset Quality Analyzer

A beginner-friendly Python command-line project for checking the quality of CSV datasets before using them in data science or machine-learning workflows.

## Features
- Load a CSV file safely
- Show dataset shape, column names, and data types
- Detect missing values and duplicate rows
- Generate a simple numeric summary
- Check configurable required columns
- Export a Markdown quality report
- Includes sample data and unit tests

## Requirements
- Python 3.10+
- No third-party packages required

## Run
```bash
python main.py --file data/sample_students.csv
```

Create a report:
```bash
python main.py --file data/sample_students.csv --report reports/quality_report.md
```

Check required columns:
```bash
python main.py --file data/sample_students.csv --required name,age,score
```

Run tests:
```bash
python -m unittest discover -s tests -v
```

## Project structure
```text
ai_dataset_quality_analyzer/
├── main.py
├── data_loader.py
├── analyzer.py
├── report_generator.py
├── exceptions.py
├── data/
│   └── sample_students.csv
├── reports/
├── tests/
│   └── test_analyzer.py
└── README.md
```

## Suggested Git practice
1. Push this project to your practice repository using your **practice/owner account**.
2. Switch to your main learning account.
3. Fork the practice repository (or use the second account's repository as upstream).
4. Clone your fork, create a branch, make a small improvement, commit, and open a pull request.
5. Review and merge the PR from the practice/owner account.

Use accounts you control and clearly treat this as a learning sandbox.
